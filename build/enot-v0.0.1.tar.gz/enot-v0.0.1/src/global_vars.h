// global_vals.h defines global(shared) variables
#ifndef GLOBAL_VARS_H
#define GLOBAL_VARS_H

extern int test_int;
int test_int = 100;

#endif
