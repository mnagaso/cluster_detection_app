#include <stdio.h>

#include "global_vars.h"
#include "read_input.h"

int main()
{
    //here is the root of the entire of this code
    //0. define global
    //1. read input file
    //2. initialize
    //3. iterate
    //4. output 
    printf("test call global int %i \n",test_int);

    return 0;
}
