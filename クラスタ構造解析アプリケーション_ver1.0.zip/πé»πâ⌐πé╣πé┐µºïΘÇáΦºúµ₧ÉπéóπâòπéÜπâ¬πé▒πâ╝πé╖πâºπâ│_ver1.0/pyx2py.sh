#!/bin/sh

rename "s/pyx/py/" ./lib/*.pyx
